/*
 * PIC18F1220 Weak Pull Up Resistor
 * And Disabling Analog Input on Port B
 */
#include <xc.h>
#include "config.h"

void main(void){
    /*Clear Port B IO*/
    PORTB=0x00;
    LATB=0x00;
    /*Disable Analog Input Function*/
    ADCON1=0x70;
    /*RB0...3 digital input*/
    TRISB=0x0F;
    /*Turn on Weak Pull Up*/
    nRBPU=0;
    while(1){
        PORTB<<=4;
    }
}