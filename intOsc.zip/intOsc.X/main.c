/*
 * PIC18F1220 internal RC oscillator
 * and its I/O
 */
#include <xc.h>
#include "config.h"

#define _XTAL_FREQ  4000000

void main(void){
    /*Select 4MHz internal oscillator*/
    OSCCONbits.IRCF=0x06;
    /*Clear IO*/
    PORTA=0x00;
    LATA=0x00;
    /*Disable analog input function*/
    ADCON1=0x7F;
    /*RA0 digital input*/
    TRISA=0x01;
    while(1){
        RA7^=1;
        LATA6=RA0;
        __delay_ms(250);
    }
}
