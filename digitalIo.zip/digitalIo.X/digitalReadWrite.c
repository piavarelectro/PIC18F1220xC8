/*
 * PIC18F1220 digital I/O Reading
 */
#include <xc.h>
#include "config.h"

#define SW1     RB6
#define LED1    RB7

void main(void){
    /*Clear I/O*/
    LATB=0x00;
    PORTB=0x00;
    /*RB6 digital input*/
    TRISB=0x40;
    while(1){
        /*Check input status*/
        if(RB6==1){
            /*Wait until SW1 released*/
            while(RB6==1);
            /*Toggle LED1*/
            LATB^=0x80;
        }
    }
}
